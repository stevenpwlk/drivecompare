#!/usr/bin/env bash
set -euo pipefail

BACKEND_URL=${BACKEND_URL:-http://localhost:8000}
GUI_HTTPS_URL=${GUI_HTTPS_URL:-https://localhost:5801}

echo "Checking backend health..."
curl -fsS "${BACKEND_URL}/health" >/dev/null

echo "Checking UI..."
curl -fsS "${BACKEND_URL}/" >/dev/null

echo "Checking worker readiness (via backend)..."
ready=$(curl -sS "${BACKEND_URL}/api/worker/ready" || true)
echo "$ready" | grep -q '"ok"[[:space:]]*:[[:space:]]*true' || {
  echo "Worker not ready: $ready" >&2
  exit 1
}

echo "Running Leclerc search (coca)..."
payload=$(curl -sS "${BACKEND_URL}/api/leclerc/search?q=coca&limit=5" || true)

if echo "$payload" | grep -q '"ok"[[:space:]]*:[[:space:]]*true'; then
  echo "Search OK"
  echo "$payload"
else
  if echo "$payload" | grep -q '"message"[[:space:]]*:[[:space:]]*"captcha_required"'; then
    echo "Search blocked as expected (captcha_required). Open the GUI to unblock: ${GUI_HTTPS_URL}"
    echo "$payload"
  elif echo "$payload" | grep -q '"message"[[:space:]]*:[[:space:]]*"2fa_required"'; then
    echo "Login requires 2FA. Open the GUI to complete: ${GUI_HTTPS_URL}"
    echo "$payload"
  else
    echo "Search failed unexpectedly: $payload" >&2
    exit 1
  fi
fi

echo "Smoke test complete."
